// Задание 1

//let a = 10;
//alert (a);
//a = 20;
//alert (a);

// Задание 2

//const dateIPhone = 2007;
//console. log(dateIPhone);

// Задание 3

//const nameCreatorJS = "Брэндан Эйх";
//console. log(nameCreatorJS);

// Задание 4

//let c = 10;
//let d = 2;

//let sum = 10 + 2;
//alert (12);

//let difference = 10 - 2;
//alert (8);

//let product = 10 * 2;
//alert (20);

//let quotient = 10 / 2;
//alert (5);

// Задание 5

//let result = 2 ** 5;
//alert (32);

// Задание 6

//let a = 9;
//let b = 2;
//let result = a % b;
//alert (1);

// Задание 7

//let num = 1;
//num += 5;
//num -= 3;
//num *= 7;
//num /= 3;
//num += 1;
//num -= 1;
//alert(num);

// Задание 8

//let age = prompt ("Сколько вам лет?");
//alert (age);

// Задание 9

const user = {
//name: "Natalya",
//age: 36,
//isAdmin: true,
}

// Задание 10

//let userName = prompt('Как вас зовут?');
//alert(`Привет, ${userName}!`)